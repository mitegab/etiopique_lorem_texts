# etiopique_lorem_texts
# Lorem Ipsum Generator (Amharic and English)

A simple Python package to generate Lorem Ipsum text in both English and Amharic languages.

## Installation

```bash
pip install etiopique-lorem-texts